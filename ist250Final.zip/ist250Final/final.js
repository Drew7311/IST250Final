//reload()

function function1() {
  document.getElementById("text").innerHTML = "You squeeze through the cracks in the wall and find yourself outside the dungeon. You're in a large cavern of sorts, and it sure is dark down here. In front of you is a sketchy bridge made of old wooden planks. You could go around, but who knows when the guards will discover that you're missing... "

  document.getElementById("button1").innerHTML = "Take the bridge";
  document.getElementById("button1").onclick = function() { l1(); };

  document.getElementById("button2").innerHTML = "Go around";
  document.getElementById("button2").onclick = function() { l2(); };
}

function function2() {
  document.getElementById("text").innerHTML = "You go right. It's not a good idea to get lost down here. Almost immediately, you run into a napping guard with a short sword. The path continues onwards, but the guard may have something useful. There's a broken bottle on the ground..."

  document.getElementById("button1").innerHTML = "Fight";
  document.getElementById("button1").onclick = function() { r1(); };

  document.getElementById("button2").innerHTML = "Sneak Past";
  document.getElementById("button2").onclick = function() { r2(); };
}

//***********************************level 2 -- 4 functions****************************************
//bridge
function l1() {
  document.getElementById("text").innerHTML = "You start walking on the bridge, but you quickly realize you made a mistake as the wood starts to crack. You try to get off, but the bridge collapses under your feet. Maybe you're too trusting of weird bridges..."
  document.getElementById("header").innerHTML = "Game Over!"

  document.getElementById("button1").innerHTML = "Start Over";
  document.getElementById("button1").onclick = function() { reset(); };

  document.getElementById("button2").innerHTML = "Start Over";
  document.getElementById("button2").onclick = function() { reset(); };
    document.getElementById("button2").style.visibility = "hidden";
  document.body.style.background = "red";
}
//go around
function l2() {
  document.getElementById("text").innerHTML = "You see a slime with some random objects floating inside. It doesn't seem to be paying attention to you, but it could have something of value. Now might be be a good time to stamp it out..."

  document.getElementById("button1").innerHTML = "Fight";
  document.getElementById("button1").onclick = function() { l21(); };

  document.getElementById("button2").innerHTML = "Sneak Past";
  document.getElementById("button2").onclick = function() { l22(); };
}

//fight
function r1() {
  document.getElementById("text").innerHTML = "You manage to win the fight, but it is louder than anticipated. You hear more guards heading your way in the distance behind you. You know you need to leave, but maybe you can find something useful first..."
  document.getElementById("button1").innerHTML = "Search the guard's body";
  document.getElementById("button1").onclick = function() { r11(); };

  document.getElementById("button2").innerHTML = "Flee";
  document.getElementById("button2").onclick = function() { r12(); };
}

//sneak past
function r2() {
  document.getElementById("text").innerHTML = "You try to sneak past, but you step on a shard of broken glass and alert the guard. After losing the element of suprise, you find yourself captured and back in your cell. Maybe after a few weeks you can whittle down those chains again... "
  document.getElementById("header").innerHTML = "Game Over!"

  document.getElementById("button1").innerHTML = "Start Over";
  document.getElementById("button1").onclick = function() { reset(); };

  document.getElementById("button2").innerHTML = "Start Over";
  document.getElementById("button2").onclick = function() { reset(); };
    document.getElementById("button2").style.visibility = "hidden";
    document.body.style.background = "red";
}

//*****************************************level 3***********************************
//search
function r11() {
  document.getElementById("text").innerHTML = "You quickly search the body and find a set of keys and the guard's shortsword. You start running and find yourself at the door to escape. Good thing you grabbed those keys!"
  document.getElementById("header").innerHTML = "You Win!"
  document.getElementById("button1").innerHTML = "Start Over";
  document.getElementById("button1").onclick = function() { reset(); };

  document.getElementById("button2").innerHTML = "Start Over";
  document.getElementById("button2").onclick = function() { reset(); };
    document.getElementById("button2").style.visibility = "hidden";
    document.body.style.background = "lightgreen";
}

//run
function r12() {
  document.getElementById("text").innerHTML = "You get out of there as fast as you can. You quickly find youself in front of a locked door with no where to go. You see the light streaming through, but the guards are almost upon you now. You wonder what will happen to you now..."
  document.getElementById("header").innerHTML = "Game Over!"

  document.getElementById("button1").innerHTML = "Start Over";
  document.getElementById("button1").onclick = function() { reset(); };

  document.getElementById("button2").innerHTML = "Start Over";
  document.getElementById("button2").onclick = function() { reset(); };
  document.getElementById("button2").style.visibility = "hidden";
  document.body.style.background = "red";
}

function l21() {
  document.getElementById("text").innerHTML = "You step on the slime, but to your suprise it only grabs your foot. It doesn't seem like you'll be going anywhere for a little while. Hopefully the guards show up eventually..."
  document.getElementById("header").innerHTML = "Game Over!"

  document.getElementById("button1").innerHTML = "Start Over";
  document.getElementById("button1").onclick = function() { reset(); };

  document.getElementById("button2").innerHTML = "Start Over";
  document.getElementById("button2").onclick = function() { reset(); };
    document.getElementById("button2").style.visibility = "hidden";
    document.body.style.background = "red";
}

function l22() {
  document.getElementById("text").innerHTML = "You move past the slime. It doesn't bother you as you slip by. After continuing down the path, you find yourself in front of a sphinx. The sphinx speaks: 'What is greater than God? Worse than evil? The rich require it. The poor have it. And if you eat it, you die. What is it?'"

  document.getElementById("button1").innerHTML = "Fight the sphinx";
  document.getElementById("button1").onclick = function() { l221(); };

  document.getElementById("button2").innerHTML = "Love";
  document.getElementById("button2").onclick = function() { l222(); };

  document.getElementById("nothing").style.visibility = "visible";
  document.getElementById("words").style.visibility = "visible";
}

//fight
function l221() {
  document.getElementById("text").innerHTML = "You try to fight the sphinx, but you don't have a weapon. You're killed almost immediately. Maybe you shouldn't try to fight mythical beasts..."
  document.getElementById("header").innerHTML = "Game Over!"

  document.getElementById("button1").innerHTML = "Start Over";
  document.getElementById("button1").onclick = function() { reset(); };

  document.getElementById("button2").innerHTML = "Start Over";
  document.getElementById("button2").onclick = function() { reset(); };
  document.body.style.background = "red";

  document.getElementById("nothing").style.visibility = "hidden";
  document.getElementById("words").style.visibility = "hidden";
    document.getElementById("button2").style.visibility = "hidden";
}

//love
function l222() {
  document.getElementById("text").innerHTML = "You chose incorrectly. The sphinx seems to grin as it moves towards you to cut you down. You should've thought a little bit longer..."
  document.getElementById("header").innerHTML = "Game Over!"

  document.getElementById("button1").innerHTML = "Start Over";
  document.getElementById("button1").onclick = function() { reset(); };

  document.getElementById("button2").innerHTML = "Start Over";
  document.getElementById("button2").onclick = function() { reset(); };

  document.getElementById("nothing").style.visibility = "hidden";
  document.getElementById("words").style.visibility = "hidden";
    document.getElementById("button2").style.visibility = "hidden";
    document.body.style.background = "red";
}

function nothing() {
  document.getElementById("text").innerHTML = "You chose correctly. The sphinx moves aside to let you pass out into the open air. You've escaped the dungeon!"
  document.getElementById("header").innerHTML = "You Win!"

  document.getElementById("button1").innerHTML = "Start Over";
  document.getElementById("button1").onclick = function() { reset(); };

  document.getElementById("button2").innerHTML = "Start Over";
  document.getElementById("button2").onclick = function() { reset(); };

  document.getElementById("nothing").style.visibility = "hidden";
  document.getElementById("words").style.visibility = "hidden";
    document.getElementById("button2").style.visibility = "hidden";
    document.body.style.background = "lightgreen";
}

function words() {

  document.getElementById("text").innerHTML = "You chose incorrectly. The sphinx seems to grin as it moves towards you to cut you down. You should've thought a little bit longer..."
  document.getElementById("header").innerHTML = "Game Over!"

  document.getElementById("button1").innerHTML = "Start Over";
  document.getElementById("button1").onclick = function() { reset(); };

  document.getElementById("button2").innerHTML = "Start Over";
  document.getElementById("button2").onclick = function() { reset(); };

  document.getElementById("nothing").style.visibility = "hidden";
  document.getElementById("words").style.visibility = "hidden";
  document.getElementById("button2").style.visibility = "hidden";
  document.body.style.background = "red";
}


function reset() {
  window.location.reload(true);
}
